"""Application version.

We keep this as a simple numeric dotted string so it can be surfaced in the UI
and used for operational debugging ("which build is running?").
"""

# Three-part numeric version (major.minor.patch)
VERSION = "5.1.8.1"
